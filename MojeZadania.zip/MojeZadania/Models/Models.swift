import Foundation

struct TaskItem: Identifiable, Codable, Equatable {
    var id = UUID()
    var title: String
    var subject: Subject
    var dueDate: Date
    var isDone: Bool = false
    var creationDate: Date = Date() // ← dodane tu
}

struct Subject: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var color: String
}
