import Foundation

class DataManager {
    static let shared = DataManager()

    private let tasksKey = "saved_tasks"
    private let subjectsKey = "saved_subjects"

    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()

    func saveTasks(_ tasks: [TaskItem]) {
        if let data = try? encoder.encode(tasks) {
            UserDefaults.standard.set(data, forKey: tasksKey)
        }
    }

    func loadTasks() -> [TaskItem] {
        guard let data = UserDefaults.standard.data(forKey: tasksKey),
              let tasks = try? decoder.decode([TaskItem].self, from: data)
        else { return [] }

        // Filtr zadań z ostatnich 7 dni
        let weekAgo = Calendar.current.date(byAdding: .day, value: -7, to: Date()) ?? Date()
        return tasks.filter { $0.creationDate >= weekAgo }
    }

    func saveSubjects(_ subjects: [Subject]) {
        if let data = try? encoder.encode(subjects) {
            UserDefaults.standard.set(data, forKey: subjectsKey)
        }
    }

    func loadSubjects() -> [Subject] {
        guard let data = UserDefaults.standard.data(forKey: subjectsKey),
              let subjects = try? decoder.decode([Subject].self, from: data)
        else { return [] }

        return subjects
    }
}
