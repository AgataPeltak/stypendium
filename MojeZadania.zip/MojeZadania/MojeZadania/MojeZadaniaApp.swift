//
//  MojeZadaniaApp.swift
//  MojeZadania
//
//  Created by agatka on 28/08/2025.
//

import SwiftUI

@main
struct MojeZadaniaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
