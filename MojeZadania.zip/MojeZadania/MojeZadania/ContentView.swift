import SwiftUI

struct ContentView: View {
    @State private var subjects: [Subject] = DataManager.shared.loadSubjects()
    @State private var tasks: [TaskItem] = DataManager.shared.loadTasks()

    var body: some View {
        TabView {
            OverviewView(tasks: $tasks)
                .tabItem {
                    Label("Przegląd", systemImage: "rectangle.grid.2x2")
                }
            
            SubjectsView(subjects: $subjects, tasks: $tasks)
                .tabItem {
                    Label("Przedmioty", systemImage: "book")
                }
            
            CalendarView(tasks: $tasks)
                .tabItem {
                    Label("Kalendarz", systemImage: "calendar")
                }
        }
        .onChange(of: tasks) { newValue in
            DataManager.shared.saveTasks(newValue)
        }
        .onChange(of: subjects) { newValue in
            DataManager.shared.saveSubjects(newValue)
        }
    }
}
