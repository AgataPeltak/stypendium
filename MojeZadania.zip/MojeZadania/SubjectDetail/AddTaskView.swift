import SwiftUI

struct AddTaskView: View {
    var subject: Subject
    @Binding var tasks: [TaskItem]
    
    @Environment(\.dismiss) var dismiss
    @State private var title = ""
    @State private var dueDate = Date()

    var body: some View {
        NavigationView {
            Form {
                TextField("Zadanie", text: $title)
                DatePicker("Na kiedy:", selection: $dueDate, displayedComponents: .date)
            }
            .navigationTitle("Nowe zadanie")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Zapisz") {
                        let newTask = TaskItem(title: title, subject: subject, dueDate: dueDate)
                        tasks.append(newTask)
                        dismiss()
                    }
                    .disabled(title.isEmpty)
                }
                ToolbarItem(placement: .cancellationAction) {
                    Button("Anuluj") {
                        dismiss()
                    }
                }
            }
        }
    }
}
