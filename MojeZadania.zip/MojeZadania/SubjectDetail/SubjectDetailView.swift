import SwiftUI

struct SubjectDetailView: View {
    var subject: Subject
    @Binding var tasks: [TaskItem]
    @State private var showAddTask = false

    var body: some View {
        VStack {
            List {
                ForEach(tasks.filter { $0.subject == subject }) { task in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(task.title)
                                .font(.headline)
                            Text(task.dueDate.formatted(.dateTime.day().month(.wide).year()))                        }
                        Spacer()
                        if task.isDone {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                        }
                    }
                }
            }
        }
        .navigationTitle(subject.name)
        .toolbar {
            Button(action: {
                showAddTask.toggle()
            }) {
                Label("Dodaj", systemImage: "plus")
            }
        }
        .sheet(isPresented: $showAddTask) {
            AddTaskView(subject: subject, tasks: $tasks)
        }
    }
}
